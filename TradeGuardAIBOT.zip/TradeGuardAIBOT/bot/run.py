
import time
import random

class TradeGuardAIBOT:
    def __init__(self, license_key):
        self.license_key = license_key
        self.running = False

    def validate_license(self):
        # DEMO license check
        return self.license_key.startswith("TG-")

    def analyze_market(self):
        return random.choice(["BUY", "SELL", "HOLD"])

    def execute_trade(self, signal):
        print(f"[TRADE] Signal: {signal}")

    def start(self):
        if not self.validate_license():
            print("❌ Invalid License")
            return

        print("✅ License Valid. Bot Started.")
        self.running = True

        while self.running:
            signal = self.analyze_market()
            if signal != "HOLD":
                self.execute_trade(signal)
            time.sleep(5)

if __name__ == "__main__":
    key = input("Enter License Key: ")
    bot = TradeGuardAIBOT(key)
    bot.start()
